using System;

namespace Octodiff.Core
{
    public class UsageException : Exception
    {
        public UsageException(string message) : base(message)
        {
            
        }
    }
}