namespace Octodiff.Core
{
    class DeltaStatistics
    {
        public DeltaStatistics()
        {
            
        }

        public int ChunksCopied { get; set; }
        public long BytesCopied { get; set; }
    }
}