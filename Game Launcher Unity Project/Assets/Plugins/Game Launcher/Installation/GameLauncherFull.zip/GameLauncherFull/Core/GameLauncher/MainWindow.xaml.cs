﻿/// Main script of GameLauncher logic


using GameLauncherCore;
using GameLauncher.NewsInformation;
using MyToolkit.Multimedia;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Web;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Effects;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using Localization = GameLauncherCore.Localization;

namespace GameLauncher
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        // UPDATE THIS
        // Must end with '/'
        // Remote host starts with 'https://' or 'http://'
        // Local host must start with 'file:///'
        // Already working HOST_URL: https://game-launcher.net/GameLauncher/
        const string HOST_URL = "URL"; // NOT NECCESARY IF YOUR HOST IS GOOGLE DRIVE

        // If 'true' Game Launcher will use Google Drive links instead of HOST_URL
        readonly bool IsUsingGoogleDriveHost = false;

        const string MAINAPP_SUBDIRECTORY = "MainApp";

        // THIS IS THE NAME OF YOUR APP
        const string MAINAPP_EXECUTABLE = "MyApp.exe";
        /* Main app executable will be located at '{APPLICATION_DIRECTORY}/{CurrentSelectedEnvironment}/{MAINAPP_EXECUTABLE}' */

        const string SELF_PATCHER_EXECUTABLE = "SelfPatcher.exe";
        /* Self patcher executable will be located at 
           '{APPLICATION_DIRECTORY}/{PatchParameters.SELF_PATCHER_DIRECTORY}/SelfPatcher.exe' */

        // Show Server Status? Set to 'false' if you don't need this
        readonly bool ShowServerStatus = true;

        // Show Release environment only?
        bool DisableBetaEnvironment = true;

        // Google Drive Host Only
        #region GOOGLE DRIVE ONLY
        /// UPDATE THESE CONSTANTS ONLY IF YOU ARE USING GOOGLE DRIVE //

        // Get Launcher VersionInfo -> It will download a 'VersionInfo.info' file.
        string LAUNCHER_VERSIONINFO_URL = "GOOGLE DRIVE URL";

        // Get Main App Release VersionInfo -> It will download a 'VersionInfo.info' file.
        string MAINAPP_RELEASE_VERSIONINFO_URL = "GOOGLE DRIVE URL";

        // Get Main App Beta VersionInfo -> It will download a 'VersionInfo.info' file.
        string MAINAPP_BETA_VERSIONINFO_URL = "GOOGLE DRIVE URL";


        /// NEWS AND LANGUAGES
        /// 
        // Get NEWS -> It will download a '.txt' file.
        // Release
        string en_US_RELEASE_NEWS_URL = "GOOGLE DRIVE URL";
        string es_MX_RELEASE_NEWS_URL = "GOOGLE DRIVE URL";

        // Beta
        string en_US_BETA_NEWS_URL = "GOOGLE DRIVE URL";
        string es_MX_BETA_NEWS_URL = "GOOGLE DRIVE URL";

        /// END // UPDATE THESE CONSTANTS ONLY IF YOU ARE USING GOOGLE DRIVE //
        #endregion

        #region PATCHER INIT
        // The information below this is updated automatically, do not change them //
        // Patcher initialization 
        GameLauncherPatcher patcher;

        private string launcherDirectory;
        private string mainAppDirectory;
        private string selfPatcherPath;

        private PatcherAsyncListener patcherListener;

        private bool isPatchingLauncher;

        private delegate void InvokeDelegate ();

        private string rootPath;

        private string MY_ACCOUNT_URL = "";
        private string WEBPAGE_URL = "";
        private string PATCH_NOTES_URL = "";
        private string REPORT_BUG_URL = "";
        private string TERMS_OF_SERVICE_URL = "";
        private string PRIVACY_POLICY_URL = "";

        private NewsContent newsContent;
        private string NEWS_CURRENT_URL = "";

        // Get MainApp VersionInfo -> It will download a 'VersionInfo.info' file.
        string MAINAPP_VERSIONINFO_URL = "URL";

        string currentRegion = "-";
        string currentAppVersion = "-";

        string currentLauncherVersion = "-";

        readonly List<string> ENVIRONMENT = new List<string> { "Release", "Beta" }; // Do not change the values

        string CurrentSelectedEnvironment = "Release"; // This value represent a folder

        CefSharp.Wpf.ChromiumWebBrowser _browser;
        IntPtr _hWnd = IntPtr.Zero;

        List<Rectangle> slideShowRectanglesList = new List<Rectangle> ();
        #endregion

        public MainWindow ()
        {
            // Show splash screen for 0.25 seconds more after loading
            System.Threading.Thread.Sleep (250);


            // Initialize Program
            InitializeComponent ();
            RenderOptions.SetBitmapScalingMode (this, BitmapScalingMode.Fant);

            // Refresh UI Language
            RefreshUILanguage ();

            // get current window handle;
            {
                _hWnd = new WindowInteropHelper (this).Handle;
            }

            // create chrome browser.
            // need to do this programatically because it's 
            // bugging up when directly added in XAML
            {
                _browser = new CefSharp.Wpf.ChromiumWebBrowser ();
                this.News_Video.Children.Add (_browser);
            }

            rootPath = Directory.GetCurrentDirectory ();

            // Assign on click interactions
            ReportBug_Button.Click += (s, e) => ReportBugButtonClicked ();
            mediaElement.MouseDown += (s, e) => SlideShow (true);
            _browser.PreviewMouseDown += (s, e) => SlideShow (true);

            InitializeLauncher ();

        }

        public void InitializeLauncher ()
        {

            // Update links automatically
            if (IsUsingGoogleDriveHost)
            {
                if (CurrentSelectedEnvironment == "Release")
                {
                    MAINAPP_VERSIONINFO_URL = MAINAPP_RELEASE_VERSIONINFO_URL;
                }
                else
                {
                    MAINAPP_VERSIONINFO_URL = MAINAPP_BETA_VERSIONINFO_URL;
                }
            }
            else // If using custom host
            {
                LAUNCHER_VERSIONINFO_URL = HOST_URL + "Launcher/" + "VersionInfo.info";
                MAINAPP_VERSIONINFO_URL = HOST_URL + "App/" + CurrentSelectedEnvironment + "/" + "VersionInfo.info";

                /// Update News URLS
                // Release
                en_US_RELEASE_NEWS_URL = HOST_URL + "News/Release/en_US_Release_News.txt";
                es_MX_RELEASE_NEWS_URL = HOST_URL + "News/Release/es_MX_Release_News.txt";

                // Beta
                en_US_BETA_NEWS_URL = HOST_URL + "News/Beta/en_US_Beta_News.txt";
                es_MX_BETA_NEWS_URL = HOST_URL + "News/Beta/es_MX_Beta_News.txt";
            }

            // PATCHER //

            // Initialize GameLauncher
            patcher = new GameLauncherPatcher (rootPath, LAUNCHER_VERSIONINFO_URL);

            // Assign directorys
            launcherDirectory = System.IO.Path.GetDirectoryName (PatchUtils.GetCurrentExecutablePath ());
            mainAppDirectory = System.IO.Path.Combine (launcherDirectory, CurrentSelectedEnvironment, MAINAPP_SUBDIRECTORY);
            selfPatcherPath = PatchUtils.GetDefaultSelfPatcherExecutablePath (SELF_PATCHER_EXECUTABLE);

            // Hide menus
            LoadingContent_ScrollViewer.Visibility = Visibility.Visible;
            Content_ScrollViewer.Visibility = Visibility.Hidden;
            Alert_Menu.Visibility = Visibility.Collapsed;
            Settings_Canvas.Visibility = Visibility.Collapsed;

            // Hide default subnews
            ExampleOnly_Content.Visibility = Visibility.Collapsed;
            Content1.Visibility = Visibility.Collapsed;
            Content2.Visibility = Visibility.Collapsed;
            Content3.Visibility = Visibility.Collapsed;
            SlideShow_News1.Visibility = Visibility.Collapsed;
            SlideShow_News2.Visibility = Visibility.Collapsed;
            SlideShow_News3.Visibility = Visibility.Collapsed;

            if (DisableBetaEnvironment)
            {
                Dropdown_Environment.Items.RemoveAt (1);
            }


            // Hide/Clear Texts
            ClearTexts ();

            currentLauncherVersion = PatchUtils.GetCurrentAppVersion ();
            launcherVersionLabel.Text = string.IsNullOrEmpty (currentLauncherVersion) ? "1.0.0" : (currentLauncherVersion);
            LAUNCHER_VERSION_2.Content = string.IsNullOrEmpty (currentLauncherVersion) ? "1.0.0" : (currentLauncherVersion);

            currentAppVersion = patcher.NewVersion;
            lbl_RegionVersion.Text = string.Format (GameLauncherCore.Localization.Get (LocalizationID.MainUI_RegionVersion), currentRegion, currentLauncherVersion);

            // Get News / Changelog 
            // Refresh UI Language
            RefreshUILanguage ();

            // Set callbacks for listening patcher changes
            patcherListener = new PatcherAsyncListener ();

            // See the another status log in the Launcher
            // Uncomment this to get more details in StatusText
            //patcherListener.OnLogReceived += (log) => {
            //    UpdateLabel (statusText, log);
            //};

            patcherListener.OnProgressChanged += (progress) =>
            {
                UpdateLabel (progressTextDetail, progress.ProgressInfo); // Use progress.ProgressNoFileInfo for less details
                //UpdateLabel (progressText, string.Format ("{0}%", progress.Percentage));
                UpdateProgressbar (singleProcessProgressBar, progress.Percentage);
            };
            patcherListener.OnOverallProgressChanged += (progress) =>
            {
                UpdateLabel (progressText, string.Format ("{0}%", progress.Percentage));
                UpdateProgressbar (overallProgressBar, progress.Percentage);
            };

            patcherListener.OnVersionInfoFetched += (versionInfo) =>
            {
                if (isPatchingLauncher)
                    versionInfo.AddIgnoredPath (MAINAPP_SUBDIRECTORY + "/");
            };
            patcherListener.OnVersionFetched += (currVersion, newVersion) =>
            {
                if (isPatchingLauncher)
                    UpdateLabel (launcherVersionLabel, currVersion);
            };

            patcherListener.OnFinish += () =>
            {
                if (patcher.Operation == PatchOperation.CheckingForUpdates)
                    CheckForUpdatesFinished ();
                else
                    PatchFinished ();
            };

            // Initalize patcher
            if (!StartLauncherPatch ())
                StartMainAppPatch (true);
        }

        private LauncherStatus _status;

        internal LauncherStatus Status
        {
            get => _status;
            set
            {
                _status = value;

            }
        }

        /// <summary>
        /// Refresh the UI Language and all his texts
        /// </summary>
        public void RefreshUILanguage ()
        {
            try
            {
                /// Main UI //
                // TopSide Options
                TopButton_MyAccount.Text = GameLauncherCore.Localization.Get (LocalizationID.MainUI_TopOptions_MyAccount);
                TopButton_Forum.Text = GameLauncherCore.Localization.Get (LocalizationID.MainUI_TopOptions_Forum);

                lbl_RegionVersion.Text = string.Format (GameLauncherCore.Localization.Get (LocalizationID.MainUI_RegionVersion), currentRegion, currentAppVersion);

                // Main Button
                // Bug Fix #2 - Commented because causes wrong Launcher Status
                //SetLauncherStatus (_status);
                if (_status == LauncherStatus.ready)
                {
                    PlayButtonText.Text = GameLauncherCore.Localization.Get (LocalizationID.MainUI_MainButtonState_Play);
                }
                else if (_status == LauncherStatus.failed)
                {
                    PlayButtonText.Text = GameLauncherCore.Localization.Get (LocalizationID.MainUI_MainButtonState_Retry);

                }
                else if (_status == LauncherStatus.downloadingUpdate)
                {
                    PlayButtonText.Text = GameLauncherCore.Localization.Get (LocalizationID.MainUI_MainButtonState_Downloading);

                }
                else if (_status == LauncherStatus.patching)
                {
                    PlayButtonText.Text = GameLauncherCore.Localization.Get (LocalizationID.MainUI_MainButtonState_Patching);

                }
                else if (_status == LauncherStatus.checking)
                {
                    PlayButtonText.Text = GameLauncherCore.Localization.Get (LocalizationID.MainUI_MainButtonState_Checking);
                }

                // Links
                // Webpage
                lbl_Webpage.Text = GameLauncherCore.Localization.Get (LocalizationID.MainUI_Links_Webpage);
                lbl_PatchNotes.Text = GameLauncherCore.Localization.Get (LocalizationID.MainUI_Links_PatchNotes);

                // Environment
                lbl_EnvironmentTitle.Text = GameLauncherCore.Localization.Get (LocalizationID.MainUI_EnvironmentTitle);

                /// Launcher Settings ///
                lbl_Settings.Content = GameLauncherCore.Localization.Get (LocalizationID.Settings);

                // LeftSide Options

                // Option 1
                // Launcher
                Settings_Option_LAUNCHER.Content = GameLauncherCore.Localization.Get (LocalizationID.Settings_MainOptions_Launcher);

                // Option 2
                // About
                Settings_Option_ABOUT.Content = GameLauncherCore.Localization.Get (LocalizationID.Settings_MainOptions_About);

                // Launcher Settings //

                // LauncherSettings/Title
                lbl_LauncherSettingsTitle.Content = GameLauncherCore.Localization.Get (LocalizationID.Settings_LauncherSettings_LauncherSettingsTitle);

                // Option 1
                // LauncherSettings/UI Language
                lbl_UILanguage.Content = GameLauncherCore.Localization.Get (LocalizationID.Settings_LauncherSettings_UILanguage);

                // About Settings //

                // ABOUT/Title
                lbl_AboutSettingsTitle.Content = GameLauncherCore.Localization.Get (LocalizationID.Settings_About_AboutSettingsTitle);

                // Option 1
                // ABOUT/Get Game Launcher
                lbl_GetGameLauncher.Content = GameLauncherCore.Localization.Get (LocalizationID.Settings_About_GetGameLauncher);

                // Option 2
                // ABOUT

                // Terms and Privacy
                TERMS_OF_SERVICE.Content = GameLauncherCore.Localization.Get (LocalizationID.TERMS_OF_SERVICE);
                PRIVACY_POLICY.Content = GameLauncherCore.Localization.Get (LocalizationID.PRIVACY_POLICY);

                // Error on Load News
                ReloadAll_ErrorLabel.Content = Localization.Get (LocalizationID.ErrorAtGetNews);

                // Refresh
                RefreshAll_lbl_Reload.Content = Localization.Get (LocalizationID.Refresh);

                FetchNews ();
            }
            catch { }
        }

        /// <summary>
        /// Sets the current launcher status, and hides other variables or content depending on the status
        /// </summary>
        /// <param name="status"></param>
        void SetLauncherStatus (LauncherStatus status)
        {
            _status = status;

            switch (status)
            {
                case LauncherStatus.ready:
                    statusText.Text = "";
                    progressTextDetail.Text = "";
                    PlayButtonText.Text = GameLauncherCore.Localization.Get (LocalizationID.MainUI_MainButtonState_Play);

                    PlayButton.Click += (s, e) => PlayButtonClicked ();

                    singleProcessProgressBar.Visibility = Visibility.Hidden;
                    singleProcessProgressBar_Background.Visibility = Visibility.Hidden;


                    overallProgressBar.Visibility = Visibility.Hidden;
                    overallProgressBar_Background.Visibility = Visibility.Hidden;

                    progressText.Visibility = Visibility.Hidden;

                    UpdateProgressbar (singleProcessProgressBar, 0);
                    UpdateProgressbar (overallProgressBar, 0);
                    UpdateLabel (progressText, "");

                    PlayButton.Background = new SolidColorBrush (System.Windows.Media.Color.FromArgb (255, 0, 194, 203));
                    PlayButton.IsEnabled = true;
                    currentAppVersion = patcher.NewVersion;
                    lbl_RegionVersion.Text = string.Format (GameLauncherCore.Localization.Get (LocalizationID.MainUI_RegionVersion), currentRegion, currentAppVersion);
                    break;
                case LauncherStatus.failed:
                    //statusText.Text = "Update Failed";
                    PlayButtonText.Text = GameLauncherCore.Localization.Get (LocalizationID.MainUI_MainButtonState_Retry);

                    PlayButton.Click += (s, e) => PatchButtonClicked ();

                    UpdateLabel (statusText, "");
                    //singleProcessProgressBar.Visibility = Visibility.Hidden;
                    //overallProgressBar.Visibility = Visibility.Hidden;
                    //progressText.Visibility = Visibility.Hidden;

                    PlayButton.Background = new SolidColorBrush (System.Windows.Media.Color.FromArgb (255, 120, 0, 0));
                    PlayButton.IsEnabled = true;
                    break;
                case LauncherStatus.downloadingUpdate:
                    statusText.Text = GameLauncherCore.Localization.Get (LocalizationID.MainUI_MainButtonState_DownloadingUpdate);
                    PlayButtonText.Text = GameLauncherCore.Localization.Get (LocalizationID.MainUI_MainButtonState_Downloading);
                    //overallProgressBar.Visibility = Visibility.Visible;
                    //progressText.Visibility = Visibility.Visible;

                    PlayButton.Background = new SolidColorBrush (System.Windows.Media.Color.FromArgb (32, 0, 79, 120));
                    PlayButton.IsEnabled = false;
                    break;
                case LauncherStatus.patching:
                    statusText.Text = GameLauncherCore.Localization.Get (LocalizationID.MainUI_MainButtonState_Patching);
                    PlayButtonText.Text = GameLauncherCore.Localization.Get (LocalizationID.MainUI_MainButtonState_Patching);
                    //overallProgressBar.Visibility = Visibility.Visible;
                    //progressText.Visibility = Visibility.Visible;

                    PlayButton.Background = new SolidColorBrush (System.Windows.Media.Color.FromArgb (32, 204, 0, 204));
                    PlayButton.IsEnabled = false;
                    break;
                case LauncherStatus.checking:
                    statusText.Text = GameLauncherCore.Localization.Get (LocalizationID.MainUI_MainButtonState_Checking);
                    PlayButtonText.Text = GameLauncherCore.Localization.Get (LocalizationID.MainUI_MainButtonState_Checking);
                    //overallProgressBar.Visibility = Visibility.Visible;
                    // progressText.Visibility = Visibility.Visible;

                    PlayButton.Background = new SolidColorBrush (System.Windows.Media.Color.FromArgb (32, 201, 192, 0));
                    PlayButton.IsEnabled = false;
                    break;
                default:
                    PlayButton.IsEnabled = false;
                    break;
            }
        }

        /// <summary>
        /// Patch button action (PlayButton uses this and PlayButtonAction)
        /// </summary>
        private void PatchButtonClicked ()
        {
            if (patcher != null && !patcher.IsRunning)
                ExecutePatch ();
        }

        /// <summary>
        /// Repair button action
        /// </summary>
        private void RepairButtonClicked ()
        {
            StartMainAppPatch (false);
        }

        /// <summary>
        /// Play button action (PlayButton uses this and PlayButtonAction)
        /// </summary>
        private void PlayButtonClicked ()
        {
            if (patcher != null && patcher.IsRunning && patcher.Operation != PatchOperation.CheckingForUpdates)
                return;

            FileInfo mainApp = new FileInfo (System.IO.Path.Combine (mainAppDirectory, MAINAPP_EXECUTABLE));
            if (mainApp.Exists)
            {
                Process.Start (new ProcessStartInfo (mainApp.FullName) { WorkingDirectory = mainApp.DirectoryName });
                Close ();
            }
            else
                UpdateLabel (statusText, GameLauncherCore.Localization.Get (LocalizationID.E_XDoesNotExist, MAINAPP_EXECUTABLE));
        }

        /// <summary>
        /// Report button action
        /// </summary>
        private void ReportBugButtonClicked ()
        {
            // Open link
            OpenURL (REPORT_BUG_URL);
        }

        /// <summary>
        /// Starts the launcher patch action
        /// </summary>
        /// <returns>Returns true if the action was completed correctly</returns>
        private bool StartLauncherPatch ()
        {
            if (string.IsNullOrEmpty (LAUNCHER_VERSIONINFO_URL) || LAUNCHER_VERSIONINFO_URL == "URL" || LAUNCHER_VERSIONINFO_URL == "GOOGLE DRIVE URL")
            {
                //MessageBox.Show ("Please set a valid URL to LAUNCHER_VERSIONINFO_URL", "Error");
                //statusText.Text = "Please set a valid URL to LAUNCHER_VERSIONINFO_URL";

                //singleProcessProgressBar.Visibility = Visibility.Visible;

                return false;
            }

            if (patcher != null && patcher.IsRunning)
                return false;

            isPatchingLauncher = true;

            patcher = new GameLauncherPatcher (launcherDirectory, LAUNCHER_VERSIONINFO_URL).SetListener (patcherListener);
            CheckForUpdates (true);

            return true;
        }

        /// <summary>
        /// Starts the app patch action
        /// </summary>
        /// <param name="checkForUpdates"></param>
        /// <returns>Returns true if the action was completed correctly</returns>
        private bool StartMainAppPatch (bool checkForUpdates)
        {
            if (string.IsNullOrEmpty (MAINAPP_VERSIONINFO_URL) || MAINAPP_VERSIONINFO_URL == "URL" || MAINAPP_VERSIONINFO_URL == "GOOGLE DRIVE URL")
            {
                //MessageBox.Show ("Please set a valid URL to MAINAPP_VERSIONINFO_URL", "Error");
                //statusText.Text = "Please set a valid URL to MAINAPP_VERSIONINFO_URL";
                return false;
            }

            if (patcher != null && patcher.IsRunning)
                return false;

            isPatchingLauncher = false;

            patcher = new GameLauncherPatcher (mainAppDirectory, MAINAPP_VERSIONINFO_URL).SetListener (patcherListener);

            if (checkForUpdates)
                CheckForUpdates (true);
            else
                ExecutePatch ();

            return true;
        }


        /// <summary>
        /// Check for updates action.
        /// | true (default): only version number (e.g. 1.0) is compared against VersionInfo to see if there is an update
        /// | false: hashes and sizes of the local files are compared against VersionInfo (if there are any different/missing files, we'll patch the app)
        /// </summary>
        /// <param name="checkVersionOnly"></param>
        private void CheckForUpdates (bool checkVersionOnly)
        {
            if (patcher.CheckForUpdates (checkVersionOnly))
            {
                SetLauncherStatus (LauncherStatus.checking);
            }
        }

        /// <summary>
        /// Execute patch action
        /// </summary>
        private void ExecutePatch ()
        {
            if (patcher.Operation == PatchOperation.ApplyingSelfPatch)
            {
                ApplySelfPatch ();
            }
            else if (patcher.Run (isPatchingLauncher))
            {
                RunOnMainThread (() => SetLauncherStatus (LauncherStatus.downloadingUpdate));
            }
        }

        /// <summary>
        /// Apply self patch action
        /// </summary>
        private void ApplySelfPatch ()
        {
            patcher.ApplySelfPatch (selfPatcherPath, PatchUtils.GetCurrentExecutablePath ());
        }

        /// <summary>
        /// Check for updates. If the launcher is already up to date, check for updates in the app.
        /// </summary>
        private void CheckForUpdatesFinished ()
        {
            // MessageBox.Show ($"Failed: {patcher.Result.ToString()}");

            if (patcher.Result == PatchResult.AlreadyUpToDate)
            {
                // If launcher is already up-to-date, check if there is an update for the main app
                if (isPatchingLauncher)
                {
                    StartMainAppPatch (true);
                }
                else
                {
                    RunOnMainThread (() =>
                    {
                        SetLauncherStatus (LauncherStatus.ready);
                    });
                }
            }
            else if (patcher.Result == PatchResult.Success)
            {
                // There is an update, enable the Patch button
                // ButtonSetEnabled (patchButton, true);
                // Apply update automatically
                PatchButtonClicked ();

            }
            else
            {
                // An error occurred, user can click the Patch button to try again
                //ButtonSetEnabled (patchButton, true);
                //MessageBox.Show ("Failed");
                //RunOnMainThread (() => SetLauncherStatus (LauncherStatus.failed));
                PatchButtonClicked ();
            }
        }

        /// <summary>
        /// Patch finished actions.
        /// </summary>
        private void PatchFinished ()
        {
            //ButtonSetEnabled (PlayButton, true);
            //MessageBox.Show ("Failed");
            if (patcher.Result == PatchResult.AlreadyUpToDate)
            {
                // If launcher is already up-to-date, check if there is an update for the main app
                if (isPatchingLauncher)
                {
                    StartMainAppPatch (true);
                }
                else
                {
                    RunOnMainThread (() =>
                    {
                        SetLauncherStatus (LauncherStatus.ready);
                    });
                }
            }
            else if (patcher.Result == PatchResult.Success)
            {
                // If patcher was self patching the launcher, start the self patcher executable
                // Otherwise, we have just updated the main app successfully
                if (patcher.Operation == PatchOperation.SelfPatching)
                {
                    ApplySelfPatch ();
                }
                else
                {
                    RunOnMainThread (() =>
                    {
                        SetLauncherStatus (LauncherStatus.ready);
                    });
                }
            }
            else
            {
                // An error occurred, user can click the Patch button to try again
                // ButtonSetEnabled (patchButton, true);
                //PlayButton.Background = new SolidColorBrush (System.Windows.Media.Color.FromArgb (255, 0, 120, 49));
                //MessageBox.Show ("Failed");
                RunOnMainThread (() =>
                {
                    SetLauncherStatus (LauncherStatus.failed);
                });

            }
        }

        /// <summary>
        /// Fetch the current news based in the current language and selected environment
        /// </summary>
        private void FetchNews ()
        {

            if (string.IsNullOrEmpty (en_US_RELEASE_NEWS_URL) || en_US_RELEASE_NEWS_URL == "URL" || en_US_RELEASE_NEWS_URL == "GOOGLE DRIVE URL" || en_US_RELEASE_NEWS_URL == "GOOGLE DRIVE URL")
            {
                // No valid PATCH_NOTES_URL
                //MessageBox.Show (en_US_RELEASE_NEWS_URL, "NEWS URL NOT VALID");
                return;
            }

            // Clear current lists
            slideShowRectanglesList.Clear ();
            subNewsElementsList.Clear ();

            if (SlideShow_MiniButtonList != null)
            {
                SlideShow_MiniButtonList.Children.RemoveRange (0, SlideShow_MiniButtonList.Children.Count);
            }
            if (Content_Inferior != null)
            {
                Content_Inferior.Children.RemoveRange (0, Content_Inferior.Children.Count);
            }

            // Begin news skeleton animation
            Storyboard sb = FindResource ("NewsLoadingAnimation") as Storyboard;
            sb.Begin ();

            // Hide news containers
            Content_ScrollViewer.Visibility = Visibility.Collapsed;
            LoadingContent_ScrollViewer.Visibility = Visibility.Visible;
            RefreshAll_Container.Visibility = Visibility.Collapsed;

            // Assign URL
            string url = en_US_RELEASE_NEWS_URL;

            // Get News URL by selected language

            if (Localization.CurrentLanguageISOCode == "en_US" || Localization.CurrentLanguageISOCode.ToLowerInvariant () == "en")
            {

                if (Dropdown_Environment.SelectedIndex == 0)
                {
                    url = en_US_RELEASE_NEWS_URL;
                }
                else
                {
                    url = en_US_BETA_NEWS_URL;
                }
            }
            else if (Localization.CurrentLanguageISOCode == "es_MX" || Localization.CurrentLanguageISOCode.ToLowerInvariant () == "es")
            {
                if (Dropdown_Environment.SelectedIndex == 0)
                {
                    url = es_MX_RELEASE_NEWS_URL;
                }
                else
                {
                    url = es_MX_BETA_NEWS_URL;
                }
            }
            else if (Localization.CurrentLanguageISOCode == "tr_TR" || Localization.CurrentLanguageISOCode.ToLowerInvariant () == "tr")
            {
                if (Dropdown_Environment.SelectedIndex == 0)
                {
                    //url = tr_TR_RELEASE_NEWS_URL;
                }
                else
                {
                    //url = tr_TR_BETA_NEWS_URL;
                }
            }

            if (PatchUtils.IsGoogleDriveURL (url))
                url = PatchUtils.GetGoogleDriveDownloadLinkFromUrl (url);

            // Prepare webclient to download news content
            WebClient webClient = null;

            try
            {

                webClient = new WebClient { Encoding = Encoding.UTF8 };
                webClient.DownloadStringCompleted += (sender, args) =>
                {

                    //LoadingContent_ScrollViewer.Visibility = Visibility.Hidden;

                    try
                    {
                        // Correct Result
                        if (!args.Cancelled && args.Error == null && !string.IsNullOrEmpty (args.Result))
                        {

                            // Deserialize JSON
                            newsContent = JsonSerializer.Deserialize<NewsContent> (args.Result, new JsonSerializerOptions () { PropertyNameCaseInsensitive = true });

                            // Update SlideShow
                            currentNewsElement = 0;

                            // Load / Update News
                            if (newsContent.News.Count == 0)
                            {
                                // No news available
                                Content_Superior.Visibility = Visibility.Collapsed;
                                SlideShow_Content.Visibility = Visibility.Collapsed;
                            }
                            else
                            {
                                Content_Superior.Visibility = Visibility.Visible;
                                SlideShow_Content.Visibility = Visibility.Visible;

                                UpdateNewsElement (newsContent.News[currentNewsElement]);

                                // Create SlideShow Button List
                                for (int i = 0; i < newsContent.News.Count; i++)
                                {
                                    //CreateNewsElement (newsContent.News[i]);
                                    Rectangle slideShowButton = new Rectangle
                                    {
                                        Fill = new SolidColorBrush ((Color)ColorConverter.ConvertFromString ("#FFA4A4A4")),

                                        RadiusX = 10,
                                        RadiusY = 10,

                                        Width = Math.Clamp (200 / newsContent.News.Count, 25, 100),
                                        Height = 15,

                                        Margin = new Thickness (0, 0, 5, 0),

                                        Cursor = Cursors.Hand,

                                        Style = FindResource ("SlideShowButtonsStyle") as Style
                                    };

                                    int index = i;

                                    slideShowButton.MouseDown += (s, e) =>
                                    {
                                        if (newsContent.News.Count > 0)
                                        {
                                            UpdateNewsElement (newsContent.News[index]);
                                        }

                                        currentNewsElement = index;
                                        SlideShow_RefillColor ();
                                        SlideShow (true);
                                    };

                                    //#FF0085FF
                                    //#FFA4A4A4

                                    SlideShow_MiniButtonList.Children.Add (slideShowButton);

                                    slideShowRectanglesList.Add (slideShowButton);
                                }

                                SlideShow_RefillColor ();

                                SlideShow_Button.Click += SlideShow_Button_Click;

                                // Start SlideShow
                                SlideShow_RefillColor ();
                                SlideShow (false);
                            }



                            // Update server status
                            FetchServerStatus (newsContent);

                            // Update alert
                            FetchAlertNotification (newsContent);

                            // Update URLS
                            MY_ACCOUNT_URL = newsContent.MyAccountURL;
                            WEBPAGE_URL = newsContent.WebpageURL;
                            PATCH_NOTES_URL = newsContent.PatchNotesURL;
                            TERMS_OF_SERVICE_URL = newsContent.TermsAndConditionsURL;
                            PRIVACY_POLICY_URL = newsContent.PrivacyPolicyURL;
                            MY_ACCOUNT_URL = newsContent.MyAccountURL;

                            REPORT_BUG_URL = newsContent.ReportBugURL;

                            // Create SubNews
                            for (int i = 0; i < newsContent.SubNews.Count; i++)
                            {
                                CreateSubNewsElement (newsContent.SubNews[i]);
                            }

                            LoadingContent_ScrollViewer.Visibility = Visibility.Hidden;
                            Content_ScrollViewer.Visibility = Visibility.Visible;
                            sb.Stop ();
                        }

                        else // Error
                        {
                            RefreshAll_Container.Visibility = Visibility.Visible;
                        }
                    }
                    catch (Exception e)
                    {
                        // If any error loading news succeed, make refresh button visible
                        RefreshAll_Container.Visibility = Visibility.Visible;
                        MessageBox.Show (string.Format ("{0} \n {1}", e.Message, e.StackTrace), "Error loading News JSON");
                    }


                    webClient.Dispose ();
                };

                webClient.DownloadStringAsync (new System.Uri (url));
            }
            catch
            {
                if (webClient != null)
                    webClient.Dispose ();
            }

        }

        /// <summary>
        /// Slideshow button play/pause action
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SlideShow_Button_Click (object sender, RoutedEventArgs e)
        {
            SlideShow (!slideShowIsPaused);
        }

        //public string SaveImage (string imageUrl, string filename, ImageFormat format)
        //{
        //    WebClient client = new WebClient ();
        //    Stream stream = client.OpenRead (imageUrl);
        //    System.Drawing.Bitmap bitmap;
        //    bitmap = new System.Drawing.Bitmap (stream);

        //    if (bitmap != null) {
        //        bitmap.Save (filename, format);
        //    }

        //    stream.Flush ();
        //    stream.Close ();
        //    client.Dispose ();

        //    return filename;
        //}

        int currentNewsElement = 0;

        bool slideShowIsPaused = false;
        DispatcherTimer timer;

        /// <summary>
        /// Set Slideshow play or pause state
        /// </summary>
        /// <param name="paused"></param>
        private void SlideShow (bool paused)
        {
            if (timer != null)
            {
                timer.Stop ();
            }

            slideShowIsPaused = paused;

            if (paused)
            {
                SlideShow_Button_Image.Source = new BitmapImage (new Uri (@"pack://application:,,,/Images/play-white.png"));
            }
            else
            {
                SlideShow_Button_Image.Source = new BitmapImage (new Uri (@"pack://application:,,,/Images/pause-white.png"));

                timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds (5) };
                timer.Start ();
                timer.Tick += (sender, args) =>
                {
                    NextNewsElement ();
                };
            }
        }

        /// <summary>
        /// Refills the color in the slideshow
        /// </summary>
        private void SlideShow_RefillColor ()
        {
            foreach (Rectangle rectangle in slideShowRectanglesList)
            {
                rectangle.Fill = new SolidColorBrush ((Color)ColorConverter.ConvertFromString ("#FFA4A4A4"));
            }

            // Fill rectangle color
            if (currentNewsElement < slideShowRectanglesList.Count)
            {
                slideShowRectanglesList[currentNewsElement].Fill = new SolidColorBrush ((Color)ColorConverter.ConvertFromString ("#FF0085FF"));
            }

        }

        /// <summary>
        /// Show the next element in the news slideshow
        /// </summary>
        private void NextNewsElement ()
        {
            var exists = slideShowRectanglesList.ElementAtOrDefault (currentNewsElement) != null;

            if (!exists || newsContent.News.Count == 1)
            { return; }

            // Take out the color
            slideShowRectanglesList[currentNewsElement].Fill = new SolidColorBrush ((Color)ColorConverter.ConvertFromString ("#FFA4A4A4"));

            // Next Element
            currentNewsElement++;

            // Set first element if the count was surpassed
            if (currentNewsElement >= newsContent.News.Count)
            {
                currentNewsElement = 0;
            }

            // Fill rectangle color
            slideShowRectanglesList[currentNewsElement].Fill = new SolidColorBrush ((Color)ColorConverter.ConvertFromString ("#FF0085FF"));

            // Update element
            UpdateNewsElement (newsContent.News[currentNewsElement]);
        }

        /// <summary>
        /// Show the previous element in the news slideshow
        /// </summary>
        private void PreviousNewsElement ()
        {
            var exists = slideShowRectanglesList.ElementAtOrDefault (currentNewsElement) != null;

            if (!exists || newsContent.News.Count == 1)
            { return; }

            // Take out the color
            slideShowRectanglesList[currentNewsElement].Fill = new SolidColorBrush ((Color)ColorConverter.ConvertFromString ("#FFA4A4A4"));

            // Previous Element
            currentNewsElement--;

            // If less than zero, then go to the last element
            if (currentNewsElement < 0)
            {
                currentNewsElement = newsContent.News.Count - 1;
            }

            // Fill rectangle color
            slideShowRectanglesList[currentNewsElement].Fill = new SolidColorBrush ((Color)ColorConverter.ConvertFromString ("#FF0085FF"));

            // Update element
            UpdateNewsElement (newsContent.News[currentNewsElement]);
        }

        MouseButtonEventHandler mouseButtonEventHandler;

        private async void UpdateNewsElement (News news)
        {
            Storyboard sb = (FindResource ("News_Slideshow_FadeOut") as Storyboard);
            sb.Begin ();

            await Task.Delay (500);

            // Show news content?
            if (news != null && news.showContent == true)
            {

                // We have a video URL? && show video?
                if (!string.IsNullOrEmpty (news.videoURL) && news.showVideo == true)
                {

                    _browser.Visibility = Visibility.Visible;

                    // Get VideoID from Youtube URL
                    var videoId = ExtractIDFromYoutubeURL (news.videoURL);

                    // Get and Display Video Thumbnail (new)
                    mediaElement.Source = new Uri (GetVideoThumbnail (videoId));

                    // Set Video to the Browser VideoPlayer
                    if (this._browser != null)
                    {
                        _browser.Address = string.Format ("https://www.youtube-nocookie.com/embed/{0}", videoId);
                    }

                    // Play on load
                    mediaElement.LoadedBehavior = MediaState.Play;
                }
                else
                {

                    // Disable Browser (Video Player)
                    _browser.Visibility = Visibility.Collapsed;

                    // Set interaction URL if we have one
                    if (!string.IsNullOrEmpty (news.interactionURL))
                    {

                        // Only add one time
                        if (mouseButtonEventHandler == null)
                        {
                            mouseButtonEventHandler = (s, e) => { OpenURL (news.interactionURL); };
                            mediaElement.MouseDown += mouseButtonEventHandler;
                        }
                        mediaElement.Cursor = Cursors.Hand;
                    }
                    else
                    {

                        // Disable interaction URL
                        if (mouseButtonEventHandler != null)
                        {
                            mediaElement.MouseDown -= mouseButtonEventHandler;
                        }

                        mediaElement.Cursor = null;
                    }

                    try
                    {
                        // Set element
                        mediaElement.Source = new Uri (news.imagesURL[0]);
                    }
                    catch
                    {
                        // If the URL is incorrect or the image cannot be loaded
                        // Render null
                        mediaElement.Source = null;
                    }
                }

                // Show Header
                if (news.showHeader == true)
                {
                    News_Header.Visibility = Visibility.Visible;
                    UpdateLabel (News_Header, news.header);
                }
                else
                {
                    News_Header.Visibility = Visibility.Hidden;
                }

                // Show Title
                if (news.showTitle == true)
                {
                    News_Actual_Title.Visibility = Visibility.Visible;
                    UpdateLabel (News_Actual_Title, news.title);
                }
                else
                {
                    News_Actual_Title.Visibility = Visibility.Collapsed;
                }

                // Show SubTitle
                if (news.showSubTitle == true)
                {
                    News_Actual_SubTitle.Visibility = Visibility.Visible;

                    // Default #FF24FF00

                    // Set a color if a color is defined
                    try
                    {
                        if (!string.IsNullOrEmpty (news.subtitleColor))
                        {
                            News_Actual_SubTitle.Foreground = new SolidColorBrush ((Color)ColorConverter.ConvertFromString (news.subtitleColor));
                        }
                    }
                    catch
                    {
                        // Error. The Color HEX code is not valid.
                        // Using default value
                    }

                    UpdateLabel (News_Actual_SubTitle, news.subtitle);
                }
                else
                {
                    News_Actual_SubTitle.Visibility = Visibility.Collapsed;
                }

                // Show Date
                if (news.showDate == true)
                {
                    News_Actual_Date.Visibility = Visibility.Visible;
                    UpdateLabel (News_Actual_Date, news.date?.ToString ("MM/dd/yyyy"));
                }
                else
                {
                    News_Actual_Date.Visibility = Visibility.Collapsed;
                }


                // Show Content
                UpdateLabel (News_Actual_Content, news.content);

                // Show Button
                if (news.showButton == true)
                {
                    News_Button.Visibility = Visibility.Visible;
                    UpdateLabel (News_Button_Content, news.buttonContent);
                }
                else
                {
                    News_Button.Visibility = Visibility.Collapsed;
                }

                // Update Actual News URL
                NEWS_CURRENT_URL = news.interactionURL;
            }

            else
            { // Hide content
                UpdateLabel (News_Header, "");
                UpdateLabel (News_Actual_Title, "");
                UpdateLabel (News_Actual_SubTitle, "");
                UpdateLabel (News_Actual_Date, "");
                UpdateLabel (News_Actual_Content, "");
                UpdateLabel (News_Button_Content, "");
                News_LineSeparation.Visibility = Visibility.Collapsed;
                News_Button.Visibility = Visibility.Collapsed;
            }

            Storyboard sb2 = (FindResource ("News_Slideshow_FadeIn") as Storyboard);
            sb2.Begin ();
        }

        // Sub element items
        int createdSubNewsElements = 0;
        const int columns = 3;
        int actualColumn = 0;

        int actualRow = 0;

        List<Grid> subNewsElementsList = new List<Grid> ();

        private void CreateSubNewsElement (SubNews subNews)
        {
            createdSubNewsElements++;

            // Create Grid (Content)
            Grid content = new Grid
            {
                // "Margin="0,10,10,10" Width="383" HorizontalAlignment="Left" Height="240" VerticalAlignment="Top""
                Name = "SubNewsElement" + createdSubNewsElements,
                Style = FindResource ("News_Content") as Style,
                Margin = new Thickness (5, 10, 5, 10),
                //content.Width = 383;
                Height = 240,
                HorizontalAlignment = HorizontalAlignment.Stretch,
                VerticalAlignment = VerticalAlignment.Center
            };
            content.SetValue (Grid.ColumnProperty, actualColumn);
            content.SetValue (Grid.RowProperty, actualRow);


            Content_Inferior.Children.Add (content);



            // Create Rectangle (Content_Background)
            //<Rectangle x:Name="Content1_Background" RadiusX="10" RadiusY="10" Fill="Black"/>
            Rectangle content_background = new Rectangle
            {
                Name = "SubNewsElement_Background" + createdSubNewsElements,

                RadiusX = 10,
                RadiusY = 10,
                Fill = new SolidColorBrush (System.Windows.Media.Colors.Black),
                HorizontalAlignment = HorizontalAlignment.Stretch,
                VerticalAlignment = VerticalAlignment.Stretch
            };

            content.Children.Add (content_background);

            // Create Grid (ImageContainer)
            Grid content_imageContainer = new Grid ();

            content.Children.Add (content_imageContainer);

            // Create Rectangle (Content_Image)
            //<Rectangle x:Name="Content1_Image" HorizontalAlignment="Stretch" VerticalAlignment="Stretch" RadiusX="10" RadiusY="10" MouseEnter="Content1_Image_MouseEnter" MouseLeave="Content1_Image_MouseLeave" MouseDown="Content1_Image_MouseDown" Cursor="Hand">
            Rectangle content_image = new Rectangle ();
            content_image.HorizontalAlignment = HorizontalAlignment.Stretch;
            content_image.VerticalAlignment = VerticalAlignment.Stretch;
            content_image.RadiusX = 10;
            content_image.RadiusY = 10;

            //content_image.MouseEnter += Content1_Image_MouseEnter;
            //content_image.MouseLeave += Content1_Image_MouseLeave;
            content_image.MouseDown += (s, e) => OpenURL (subNews.interactionURL);

            content_image.Cursor = Cursors.Hand;

            content_image.Effect =
                new DropShadowEffect
                {
                    Direction = -90,
                    ShadowDepth = 0,
                    Opacity = 0.5,
                    BlurRadius = 10,
                };

            content_image.Style = FindResource ("SubNewsImage") as Style;

            //ImageBrush myImageBrush = new ImageBrush (new BitmapImage (new Uri (@"pack://application:,,,/Fire Card Passive Wildfire.png", UriKind.Absolute)));

            string imagePath = subNews.imageURL;

            //imagePath = SaveImage (subNews.image, System.IO.Path.GetTempFileName(), ImageFormat.Png);

            //MessageBox.Show (imagePath, "Path");
            ImageBrush myImageBrush = new ImageBrush (new BitmapImage (new Uri (imagePath)));

            // Configure the brush so that it
            // doesn't stretch its image to fill
            // the rectangle.

            if (createdSubNewsElements == 1)
            {
                myImageBrush.Stretch = Stretch.Uniform;
            }
            else
            {
                myImageBrush.Stretch = Stretch.UniformToFill;
            }

            // Use the ImageBrush to paint the rectangle's background.
            content_image.Fill = myImageBrush;

            content_imageContainer.Children.Add (content_image);

            // Create Grid (Content_Inferior)
            // Grid Style="{DynamicResource MenuHover}" x:Name="Content1_Inferior" HorizontalAlignment="Stretch" Height="96" VerticalAlignment="Bottom" Visibility="Visible" Background="{fw:AcrylicBrush TintColor=Black, TintOpacity=0.1, NoiseOpacity=0.01, TargetName=Content1_ImageContainer}
            Grid content_inferior = new Grid ();

            content_inferior.Style = FindResource ("MenuHover") as Style;
            content_inferior.Name = "Content_Inferior" + createdSubNewsElements;
            content_inferior.HorizontalAlignment = HorizontalAlignment.Stretch;
            content_inferior.Height = 96;
            content_inferior.VerticalAlignment = VerticalAlignment.Bottom;
            content_inferior.Visibility = Visibility.Visible;

            if (subNews.showContent == false)
            {
                content_inferior.Visibility = Visibility.Collapsed;
            }
            //DrawingBrush myBrush = (Application.Current.Resources ["fw:AcrylicBrush"] as DrawingBrush).Clone ();

            //         ((System.Windows.Media.GeometryDrawing)(((System.Windows.Media.DrawingGroup)
            //(myBrush.Drawing)).Children [0])).Pen.Brush = new SolidColorBrush (Colors.Red);


            //var acrylicBrush = new SourceChord.FluentWPF.AcrylicBrushExtension {
            //    TintColor = Colors.Black,
            //    TintOpacity = 0.1,
            //    NoiseOpacity = 0.01,
            //    TargetName = content_imageContainer.Name
            //};

            //content_inferior.Background = acrylicBrush;

            content.Children.Add (content_inferior);

            // Create Rectangle (Content_Background)
            var background_rectangle = new Rectangle
            {
                Name = "SubNewsContent_BackgroundRectangle" + createdSubNewsElements,
                Fill = new SolidColorBrush ((Color)ColorConverter.ConvertFromString ("#AE000000")),
                RadiusX = 2,
                RadiusY = 2,
                IsEnabled = false,
                Effect =
                new DropShadowEffect
                {
                    Direction = -90,
                    ShadowDepth = 2,
                    Opacity = 0.75,
                    BlurRadius = 4,
                    Color = ((Color)ColorConverter.ConvertFromString ("Black"))
                }
                //Effect = new BlurEffect (),
            };

            content_inferior.Children.Add (background_rectangle);


            // Create Stack Panel
            // StackPanel HorizontalAlignment="Stretch" Orientation="Vertical" VerticalAlignment="Stretch" Margin="15,10,15,0" Visibility="Visible"
            var content_stackPanel = new StackPanel
            {
                HorizontalAlignment = HorizontalAlignment.Stretch,
                Orientation = Orientation.Vertical,
                VerticalAlignment = VerticalAlignment.Stretch,
                Margin = new Thickness (15, 10, 15, 0)
            };

            content_inferior.Children.Add (content_stackPanel);

            // Create TextBlock
            // TextBlock x:Name="Content1_Title" TextWrapping="Wrap" FontSize="14" Foreground="#FFAF00" FontFamily="Fonts/#Monserrat" TextAlignment="Left" HorizontalAlignment="Stretch" VerticalAlignment="Stretch" Margin="0,0,0,10" Text="PATCH NOTES"
            var content_title = new TextBlock
            {
                Name = "Content_Title" + createdSubNewsElements,
                TextWrapping = TextWrapping.Wrap,
                TextTrimming = TextTrimming.CharacterEllipsis,
                FontSize = 14,
                Foreground = new SolidColorBrush ((Color)ColorConverter.ConvertFromString ("#FFAF00")),
                //FontFamily = new FontFamily (new Uri ("pack://application:,,,/"), "./Fonts/#Fredoka"),

                TextAlignment = TextAlignment.Left,
                HorizontalAlignment = HorizontalAlignment.Stretch,
                VerticalAlignment = VerticalAlignment.Stretch,
                Margin = new Thickness (0, 0, 0, 10),
                Text = subNews.showTitle == true ? subNews.title : "",
                Effect =
                new DropShadowEffect
                {
                    Direction = -90,
                    ShadowDepth = 2,
                    Opacity = 0.5,
                    BlurRadius = 4,
                }
            };
            content_stackPanel.Children.Add (content_title);

            // Create TextBlock
            // TextBlock x:Name="Content1_Text" TextWrapping="Wrap" FontSize="14" Foreground="#FFDEDEDE" FontFamily="Fonts/#Monserrat" TextAlignment="Left" Text="See the complete 1.0.10 patch notes!"
            var content_text = new TextBlock
            {
                Name = "Content_Text" + createdSubNewsElements,
                TextWrapping = TextWrapping.Wrap,
                Height = 35,
                FontSize = 14,
                Foreground = new SolidColorBrush ((Color)ColorConverter.ConvertFromString ("#FFDEDEDE")),
                //FontFamily = new FontFamily (new Uri ("pack://application:,,,/"), "./Fonts/#Fredoka"),
                TextAlignment = TextAlignment.Left,

                Text = subNews.showContent == true ? subNews.content : "",
                Effect =
                new DropShadowEffect
                {
                    Direction = -90,
                    ShadowDepth = 2,
                    Opacity = 0.5,
                    BlurRadius = 4,
                }
            };
            content_stackPanel.Children.Add (content_text);

            // Create TextBlock (date)
            // TextBlock x:Name="Content1_Text" TextWrapping="NoWrap" FontSize="14" Foreground="#FF999999" FontFamily="Fonts/#Monserrat" TextAlignment="Left" Text="See the complete 1.0.10 patch notes!"
            var content_date = new TextBlock
            {
                Name = "Content_Date" + createdSubNewsElements,
                TextWrapping = TextWrapping.NoWrap,
                FontSize = 12,
                Foreground = new SolidColorBrush ((Color)ColorConverter.ConvertFromString ("#FF999999")),
                //FontFamily = new FontFamily (new Uri ("pack://application:,,,/"), "./Fonts/#Fredoka"),
                TextAlignment = TextAlignment.Left,
                Text = subNews.showDate == true ? subNews.date?.ToString ("MM/dd/yyyy") : "",
                Effect =
                new DropShadowEffect
                {
                    Direction = -90,
                    ShadowDepth = 2,
                    Opacity = 0.5,
                    BlurRadius = 4,
                }
            };
            content_stackPanel.Children.Add (content_date);

            actualColumn++;

            if (actualColumn > columns - 1)
            {
                actualColumn = 0;
                actualRow++;
                Content_Inferior.RowDefinitions.Add (new RowDefinition ());
            }

            subNewsElementsList.Add (content);
        }

        //private void FetchServerStatus ()
        //{
        //    if (string.IsNullOrEmpty (NEWS_URL) || NEWS_URL == "URL") {
        //        // No valid NEWS_URL
        //        return;
        //    }

        //    if (ShowServerStatus) {
        //        ServerStatusText.Visibility = Visibility.Visible;
        //    }
        //    else {
        //        ServerStatusText.Visibility = Visibility.Hidden;
        //        return;
        //    }

        //    WebClient webClient = null;

        //    string url = NEWS_URL;

        //    if (IsGoogleDriveURL (url))
        //        url = PatchUtils.GetGoogleDriveDownloadLinkFromUrl (url);

        //    try {
        //        webClient = new WebClient { Encoding = System.Text.Encoding.UTF8 };
        //        webClient.DownloadStringCompleted += (sender, args) => {
        //            if (!args.Cancelled && args.Error == null) {
        //                bool isServerOnline;
        //                bool.TryParse (NEWS_URL, out isServerOnline);

        //                if (args.Result == "Online" || args.Result == "online") {
        //                    isServerOnline = true;
        //                }

        //                if (isServerOnline) {
        //                    ServerStatusText.Text = string.Format ("Online🔘", isServerOnline);
        //                    ServerStatusText.Foreground = new SolidColorBrush(Colors.Lime);
        //                }
        //                else {
        //                    ServerStatusText.Text = string.Format ("Offline🔘", isServerOnline);
        //                    ServerStatusText.Foreground = new SolidColorBrush(Colors.Red);
        //                }
        //            } else {
        //                ServerStatusText.Text = string.Format (" Offline🔘", false);
        //                ServerStatusText.Foreground = new SolidColorBrush(Colors.Red);
        //            }

        //            webClient.Dispose ();
        //        };

        //        webClient.DownloadStringAsync (new System.Uri (url));
        //    }
        //    catch {
        //        if (webClient != null)
        //            webClient.Dispose ();
        //    }
        //}

        private void FetchServerStatus (NewsContent newsContent)
        {

            if (newsContent == null)
            {
                // No valid News Content
                return;
            }

            if (ShowServerStatus)
            {
                ServerStatusText.Visibility = Visibility.Visible;
            }
            else
            {
                ServerStatusText.Visibility = Visibility.Hidden;
                return;
            }


            bool isServerOnline = false;

            if (newsContent.ServerStatus == "Online" || newsContent.ServerStatus == "online")
            {
                isServerOnline = true;
            }

            if (isServerOnline)
            {
                ServerStatusText.Text = string.Format ("Online", isServerOnline);
                ServerStatusText.Foreground = new SolidColorBrush (Colors.Lime);
            }
            else
            {
                ServerStatusText.Text = string.Format ("Offline", isServerOnline);
                ServerStatusText.Foreground = new SolidColorBrush (Colors.Red);
            }
        }

        //private void FetchAlertNotification ()
        //{
        //    if (string.IsNullOrEmpty (NEWS_URL) || NEWS_URL == "URL") {
        //        return;
        //    }


        //    WebClient webClient = null;

        //    string url = NEWS_URL;

        //    if (IsGoogleDriveURL (url))
        //        url = PatchUtils.GetGoogleDriveDownloadLinkFromUrl (url);

        //    try {
        //        webClient = new WebClient { Encoding = System.Text.Encoding.UTF8 };
        //        webClient.DownloadStringCompleted += (sender, args) => {
        //            if (!args.Cancelled && args.Error == null) {

        //                if (!string.IsNullOrEmpty (args.Result)) {
        //                    AlertNotification_Text.Text = args.Result;
        //                    Alert_Menu.Visibility = Visibility.Visible;
        //                }
        //                else {
        //                    AlertNotification_Text.Text = "";
        //                    Alert_Menu.Visibility = Visibility.Collapsed;
        //                }
        //            }
        //            else {
        //                AlertNotification_Text.Text = "";
        //                Alert_Menu.Visibility = Visibility.Collapsed;
        //            }

        //            webClient.Dispose ();
        //        };

        //        webClient.DownloadStringAsync (new System.Uri (url));
        //    }
        //    catch {
        //        if (webClient != null)
        //            webClient.Dispose ();
        //    }
        //}
        private void FetchAlertNotification (NewsContent newsContent)
        {
            // Check if valid
            if ((newsContent == null && newsContent.Alerts != null && newsContent.Alerts.Count > 0) || newsContent.Alerts.Count == 0)
            {
                // No valid News Content
                Alert_Menu.Visibility = Visibility.Collapsed;
                return;
            }

            // Show after date?

            if (newsContent.Alerts[0].showAfterDate != null)
            {

                // It's the time to display it?
                if (DateTime.UtcNow < newsContent.Alerts[0].showAfterDate)
                {
                    return;
                }
            }

            if (!string.IsNullOrEmpty (newsContent.Alerts[0].message))
            {
                AlertNotification_Text.Text = newsContent.Alerts[0].message;

                Uri uri = new Uri ("pack://application:,,,/Images/warning-black.png");
                Alert_Icon.Background = (SolidColorBrush)new BrushConverter ().ConvertFrom ("#FFFFAF00");

                if (newsContent.Alerts[0].type == "Information")
                {
                    uri = new Uri ("pack://application:,,,/Images/information-button.png");
                    Alert_Icon.Background = (SolidColorBrush)new BrushConverter ().ConvertFrom ("#FF00DCDC");
                }
                else if (newsContent.Alerts[0].type == "Warning")
                {
                    uri = new Uri ("pack://application:,,,/Images/warning-black.png");
                    Alert_Icon.Background = (SolidColorBrush)new BrushConverter ().ConvertFrom ("#FFFFAF00");
                }

                //ImageBrush myImageBrush = new ImageBrush (new BitmapImage (uri));

                // Configure the brush so that it
                // doesn't stretch its image to fill
                // the rectangle.
                //myImageBrush.Stretch = Stretch.UniformToFill;

                // Use the ImageBrush to paint the rectangle's background.
                Alert_Image.Source = new BitmapImage (uri);
                Alert_Image.Stretch = Stretch.UniformToFill;

                Alert_Menu.MouseDown += new MouseButtonEventHandler (Alert_Menu_Click);
                Alert_Menu.Cursor = Cursors.Hand;
                Alert_Menu.Visibility = Visibility.Visible;
            }
            else
            {
                AlertNotification_Text.Text = "";
                Alert_Menu.Visibility = Visibility.Collapsed;
            }
        }

        void Alert_Menu_Click (object sender, MouseButtonEventArgs e)
        {
            OpenURL (newsContent.Alerts[0].interactionURL);
        }

        private void ButtonSetEnabled (Button button, bool isEnabled)
        {
            if (button.Name == "PlayButton" && isEnabled)
            {
                _status = LauncherStatus.ready;
            }
            RunOnMainThread (() => button.IsEnabled = isEnabled);
        }

        private void UpdateLabel (TextBlock label, string text, bool updateTooltip = false)
        {
            //MessageBox.Show($"{text}");
            if (updateTooltip)
            {
                RunOnMainThread (() => label.ToolTip = text);
            }

            RunOnMainThread (() => label.Text = text);
        }

        private void UpdateProgressbar (ProgressBar progressBar, int value)
        {
            if (value < 0)
                value = 0;
            else if (value > 100)
                value = 100;

            if (value > 0)
            {
                RunOnMainThread (() => overallProgressBar_Background.Visibility = Visibility.Visible);
                RunOnMainThread (() => singleProcessProgressBar_Background.Visibility = Visibility.Visible);
            }
            RunOnMainThread (() => progressBar.Value = value);
        }

        private void RunOnMainThread (InvokeDelegate function)
        {
            //if (!control.IsHandleCreated)
            //    return;

            //if (control.InvokeRequired)
            //    control.BeginInvoke (function);
            //else
            Application.Current.Dispatcher.Invoke (new Action (() => { function (); }));
        }

        /// <summary>
        /// Clear Texts of GameLauncher
        /// </summary>
        private void ClearTexts ()
        {
            // Hide Texts
            progressTextDetail.Text = string.Empty;
            News_Actual_Content.Text = Localization.Get (LocalizationID.MainUI_NoNewsAtTheMoment);
            statusText.Text = string.Empty;
            lbl_RegionVersion.Text = string.Format (Localization.Get (LocalizationID.MainUI_RegionVersion), "-", "-");
            launcherVersionLabel.Text = string.Empty;

            // Progress Bar
            overallProgressBar_Background.Visibility = Visibility.Hidden;
            singleProcessProgressBar_Background.Visibility = Visibility.Hidden;
            progressText.Text = string.Empty;
            singleProcessProgressBar.Value = 0;
            overallProgressBar.Value = 0;
        }

        /// <summary>
        /// Open settings canvas
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void OpenOrCloseSettingsCanvas ()
        {
            if (Settings_Canvas.Visibility == Visibility.Visible)
            {
                Storyboard sb = FindResource ("Settings_FadeOutAnimation") as Storyboard;
                sb.Begin ();

                Settings_Canvas.Visibility = Visibility.Collapsed;
            }
            else
            {
                Storyboard sb = FindResource ("Settings_FadeInAnimation") as Storyboard;
                sb.Begin ();

                Settings_Canvas.Visibility = Visibility.Visible;
            }
        }

        #region WINDOW LOGIC
        private void ButtonMinimize_Click (object sender, RoutedEventArgs e)
        {
            Application.Current.MainWindow.WindowState = WindowState.Minimized;
        }

        private void WindowStateButton_Click (object sender, RoutedEventArgs e)
        {
            if (Application.Current.MainWindow.WindowState != WindowState.Maximized)
            {
                Application.Current.MainWindow.WindowState = WindowState.Maximized;
            }
            else
            {
                Application.Current.MainWindow.WindowState = WindowState.Normal;
            }
        }
        private void ButtonClose_Click (object sender, RoutedEventArgs e)
        {
            Close ();
        }
        #endregion

        /// <summary>
        /// Open URL
        /// </summary>
        private void Hyperlink_RequestNavigate (object sender, RequestNavigateEventArgs e)
        {
            var uri = e.Uri.ToString ();
            var psi = new System.Diagnostics.ProcessStartInfo ();
            psi.UseShellExecute = true;
            psi.FileName = uri;
            System.Diagnostics.Process.Start (psi);
        }

        /// <summary>
        /// Open URL in external navigator
        /// </summary>
        /// <param name="URL"></param>
        private void OpenURL (string URL)
        {
            // Cancel if the URL is null
            if (string.IsNullOrEmpty (URL))
            {
                return;
            }

            // Manage invalid URL's
            try
            {
                var psi = new System.Diagnostics.ProcessStartInfo ();
                psi.UseShellExecute = true;
                psi.FileName = URL;
                System.Diagnostics.Process.Start (psi);
            }
            catch
            {

            }
        }

        public string ExtractIDFromYoutubeURL (string URL)
        {
            var uri = new Uri (URL);

            // you can check host here => uri.Host <= "www.youtube.com"

            var query = HttpUtility.ParseQueryString (uri.Query);
            var videoId = query["v"];
            return videoId;
        }
        public string GetVideoThumbnail (string ID)
        {

            // Return
            // Maximum Resolution Thumbnail
            return string.Format ("https://img.youtube.com/vi/{0}/maxresdefault.jpg", ID);

        }

        /// <summary>
        /// Show Youtube Video
        /// </summary>
        public async void ShowVideo (string URL)
        {

            string videoId = ExtractIDFromYoutubeURL (URL);

            var videoURL = await YouTube.GetVideoUriAsync (videoId, YouTubeQuality.QualityHigh);
            mediaElement.Source = videoURL.Uri;
        }


        // BUG Fix
        bool firstLoadEnvironment = false;

        private void Dropdown_Environment_SelectionChanged (object sender, SelectionChangedEventArgs e)
        {
            if (firstLoadEnvironment == false)
            {
                firstLoadEnvironment = true;
                return;
            }

            CurrentSelectedEnvironment = ENVIRONMENT[Dropdown_Environment.SelectedIndex];

            InitializeLauncher ();

            //MessageBox.Show (currentEnvironemnt);
        }

        // BUG Fix
        bool firstLoadLanguage = false;

        private void comboBox_UILanguage_SelectionChanged (object sender, SelectionChangedEventArgs e)
        {
            if (firstLoadLanguage == false)
            {
                firstLoadLanguage = true;
                return;
            }

            int selectedValue = 0;
            if (comboBox_UILanguage != null)
            {
                selectedValue = comboBox_UILanguage.SelectedIndex;

                //MessageBox.Show (selectedValue.ToString(), "Title");
            }


            switch (selectedValue)
            {
                case 0:
                    GameLauncherCore.Localization.SetLanguage ("en_US");
                    break;
                case 1:
                    GameLauncherCore.Localization.SetLanguage ("es_MX");
                    break;
                case 2:
                    GameLauncherCore.Localization.SetLanguage ("tr_TR");
                    break;
                default:
                    GameLauncherCore.Localization.SetLanguage ("en_US");
                    break;
            }

            RefreshUILanguage ();
        }
        #region PlayButton LOGIC

        /// <summary>
        /// On MouseEnter -> Start Hover Animation
        /// </summary>
        private void PlayButton_MouseEnter (object sender, System.Windows.Input.MouseEventArgs e)
        {
            Storyboard sb = (FindResource ("OnPlayButtonHover") as Storyboard);
            sb.Begin ();
        }

        /// <summary>
        /// On MouseLeave -> End Hover Animation
        /// </summary>
        private void PlayButton_MouseLeave (object sender, System.Windows.Input.MouseEventArgs e)
        {
            Storyboard sb = (FindResource ("OnPlayButtonHover") as Storyboard);
            sb.Stop ();
        }

        #endregion

        #region CONTENT_ONCLICK_LOGIC

        private void Button_News_Actual_MoreInfo_Click (object sender, RoutedEventArgs e)
        {
            // Open URL
            OpenURL (NEWS_CURRENT_URL);

        }

        private void ConfigButton_Click (object sender, RoutedEventArgs e)
        {
            OpenOrCloseSettingsCanvas ();
        }

        private void Button_RefreshAll_Click (object sender, RoutedEventArgs e)
        {
            FetchNews ();
        }
        private void MenuItem_ShowInExplorer_Click (object sender, RoutedEventArgs e)
        {
            if (Directory.Exists (rootPath))
            {
                ProcessStartInfo startInfo = new ProcessStartInfo
                {
                    Arguments = rootPath,
                    FileName = "explorer.exe"
                };

                Process.Start (startInfo);
            }

        }

        private void Topside_MouseDown (object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
                this.DragMove ();
        }

        private void Menu_Logo_MouseDown (object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            OpenOrCloseSettingsCanvas ();
        }

        private void Button_CloseSettings_Click (object sender, RoutedEventArgs e)
        {
            OpenOrCloseSettingsCanvas ();
        }

        private void DisableOtherSettings_Option ()
        {
            Settings_Option_ABOUT.IsEnabled = true;
            Settings_Option_LAUNCHER.IsEnabled = true;

            Settings_LauncherSettings.Visibility = Visibility.Collapsed;
            Settings_AboutSettings.Visibility = Visibility.Collapsed;


        }

        private void Settings_Option_LAUNCHER_Click (object sender, RoutedEventArgs e)
        {
            DisableOtherSettings_Option ();

            Settings_Option_LAUNCHER.IsEnabled = false;

            Settings_LauncherSettings.Visibility = Visibility.Visible;
        }

        private void Settings_Option_ABOUT_Click (object sender, RoutedEventArgs e)
        {
            DisableOtherSettings_Option ();

            Settings_Option_ABOUT.IsEnabled = false;
            Settings_AboutSettings.Visibility = Visibility.Visible;

        }

        private void TopButton_MyAccount_MouseDown (object sender, MouseButtonEventArgs e)
        {
            // Open URL
            OpenURL (MY_ACCOUNT_URL);
        }

        private void Button_RegionAndServer_Click (object sender, RoutedEventArgs e)
        {
            OpenOrCloseSettingsCanvas ();

        }

        private void lbl_Webpage_MouseDown (object sender, MouseButtonEventArgs e)
        {
            // Open URL
            OpenURL (WEBPAGE_URL);
        }

        private void lbl_PatchNotes_MouseDown (object sender, MouseButtonEventArgs e)
        {
            // Open URL
            OpenURL (PATCH_NOTES_URL);
        }
        private void TERMS_OF_SERVICE_MouseDown (object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            // Open Terms of Service Link
            OpenURL (TERMS_OF_SERVICE_URL);

        }
        private void PRIVACY_POLICY_MouseDown (object sender, MouseButtonEventArgs e)
        {
            // Open Privacy Policy Link
            OpenURL (PRIVACY_POLICY_URL);
        }
        private void lbl_GetGameLauncherLink_MouseDown (object sender, MouseButtonEventArgs e)
        {
            OpenURL ("https://assetstore.unity.com/packages/slug/217526");
        }

        #endregion


    }

    enum LauncherStatus
    {
        checking,
        ready,
        failed,
        downloadingUpdate,
        patching

    }
}