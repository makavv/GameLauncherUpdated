﻿namespace Octodiff.Core
{
    public interface ISignatureReader
    {
        Signature ReadSignature();
    }
}